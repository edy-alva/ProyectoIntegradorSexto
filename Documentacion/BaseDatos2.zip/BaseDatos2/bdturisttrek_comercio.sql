-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: bdturisttrek
-- ------------------------------------------------------
-- Server version	8.0.37

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `comercio`
--

DROP TABLE IF EXISTS `comercio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `comercio` (
  `idcomercio` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(200) DEFAULT NULL,
  `direccion` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`idcomercio`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comercio`
--

LOCK TABLES `comercio` WRITE;
/*!40000 ALTER TABLE `comercio` DISABLE KEYS */;
INSERT INTO `comercio` VALUES (1,'6840','4'),(2,'6590','8'),(3,'6590','8'),(4,'Imagine Ecuador','16 de Diciembre y Juan Montalvo'),(5,'Imagine Ecuador','16 de Diciembre y Juan Montalvo'),(6,'Explorjungle','Ambato y Rocafuerte'),(7,'Explorjungle','Ambato y Rocafuerte'),(8,'MTS Adventure','Ambato y Halflants'),(9,'MTS Adventure','Ambato y Halflants'),(10,'Raft Amazonia','Montalvo y Halflants'),(11,'Raft Amazonia','Montalvo y Halflants'),(12,'Ecuatrek','Eloy Alfaro y Luis A. MartÃ­nez'),(13,'Ecuatrek','Eloy Alfaro y Luis A. MartÃ­nez'),(14,'Aningatravel','Maldonado y 16 de Diciembre'),(15,'Aningatravel','Maldonado y 16 de Diciembre'),(16,'BaÃ±os Adventure','Ambato y 12 de Noviembre'),(17,'BaÃ±os Adventure','Ambato y 12 de Noviembre'),(18,'Canyoning BaÃ±os','Thomas Halflants y Montalvo'),(19,'Canyoning BaÃ±os','Thomas Halflants y Montalvo'),(20,'Ecuadorian Time','Montalvo y Ambato'),(21,'Ecuadorian Time','Montalvo y Ambato'),(22,'Comunidad de RuntÃºn','RuntÃºn, a unos 30 minutos de BaÃ±os'),(23,'Comunidad de RuntÃºn','RuntÃºn, a unos 30 minutos de BaÃ±os'),(24,'Comunidad de RÃ­o Verde','RÃ­o Verde, a unos 20 minutos de BaÃ±os en la vÃ­a a Puyo'),(25,'Comunidad de RÃ­o Verde','RÃ­o Verde, a unos 20 minutos de BaÃ±os en la vÃ­a a Puyo'),(26,'Comunidad de Ulba','Ulba, a unos 15 minutos de BaÃ±os'),(27,'Comunidad de Ulba','Ulba, a unos 15 minutos de BaÃ±os'),(28,'Comunidad de Santa Ana','Santa Ana, a unos 25 minutos de BaÃ±os'),(29,'Comunidad de Santa Ana','Santa Ana, a unos 25 minutos de BaÃ±os'),(30,'Comunidad de Lligua','Lligua, a unos 10 minutos de BaÃ±os'),(31,'Comunidad de Lligua','Lligua, a unos 10 minutos de BaÃ±os'),(32,'Comunidad de Pondoa','Pondoa, a unos 20 minutos de BaÃ±os'),(33,'Comunidad de Pondoa','Pondoa, a unos 20 minutos de BaÃ±os'),(34,'Comunidad de San MartÃ­n','San MartÃ­n, a unos 30 minutos de BaÃ±os'),(35,'Comunidad de San MartÃ­n','San MartÃ­n, a unos 30 minutos de BaÃ±os'),(36,'Comunidad CotalÃ³','CotalÃ³, a unos 40 minutos de BaÃ±os'),(37,'Comunidad CotalÃ³','CotalÃ³, a unos 40 minutos de BaÃ±os'),(38,'Comunidad Patate','Patate, a unos 45 minutos de BaÃ±os'),(39,'Comunidad Patate','Patate, a unos 45 minutos de BaÃ±os'),(40,'Comunidad de Juive','Juive, a unos 10 minutos de BaÃ±os'),(41,'Comunidad de Juive','Juive, a unos 10 minutos de BaÃ±os');
/*!40000 ALTER TABLE `comercio` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-07-17  9:33:48
